

from kernel import Data


# load order : (component|game_object),(space),(state),(state_manager)
# create pack_menu.state to implement a custom menu

Data.req = []
